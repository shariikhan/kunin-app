<template>
    <div>
        <div class="container">
            <img src="../assets/svg/page_not_found_su7k.svg" alt="">
        </div>
    </div>
</template>
<script>
export default {
    name:"Notfound",
}
</script>